package com.example.servingwebcontent;

import org.springframework.stereotype.Component;


public class Address
{
    String city;
    String state;
    String zipcode;

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    public String getZipcode() {
        return zipcode;
    }

    public String getCity() {
        return city;
    }

    public String getState() {
        return state;
    }


    public Address(String city, String state,String  zipcode) {
        this.city = city;
        this.state = state;
        this.zipcode=zipcode;
    }
}
