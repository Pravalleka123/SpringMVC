package com.example.servingwebcontent;


import org.springframework.stereotype.Component;

@Component
public class GreetingValidator
{
    boolean validator(String name)
    {
        if(name == null)
            return false;
        else
        {
            return true;
        }
    }
}
