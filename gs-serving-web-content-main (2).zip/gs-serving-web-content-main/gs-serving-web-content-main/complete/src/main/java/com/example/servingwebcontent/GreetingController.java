package com.example.servingwebcontent;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class GreetingController {

	@Autowired
	GreetingValidator gv;
	@Autowired
	GreetingService gs;
	@GetMapping("/greeting")
	public String greeting(@RequestParam(name="name", required=false) String name,
						   @RequestParam(name="show:zipcode",required=false) Boolean showZipcode,
						   Model model) {


		boolean result = gv.validator(name);
		if(result==true)
		{
			model.addAttribute("name", name);
			Customer res = gs.greetingser(name,showZipcode);
			model.addAttribute("customer",res);
		}
		else
		{
			model.addAttribute("name", "error - string is null");

		}
		return "greeting";
	}

}
