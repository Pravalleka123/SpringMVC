package com.example.servingwebcontent;

import org.springframework.stereotype.Service;

@Service
public class AddressService
{
    public Address getpresentaddress(String city,String state,String zipcode)
    {
        Address addr1=new Address(city,state,zipcode);
        return addr1;
    }
    public Address getpermanentaddress(String city,String state,String zipcode)
    {
        Address addr2=new Address(city,state,zipcode);
        return addr2;
    }
}
