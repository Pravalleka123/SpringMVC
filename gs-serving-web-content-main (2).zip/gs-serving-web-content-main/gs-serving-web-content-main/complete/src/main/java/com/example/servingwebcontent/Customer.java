package com.example.servingwebcontent;



public class Customer
{
    String name;
    String id;
    String status;
    Address presentaddress;
    Address permanentaddress;

    public void setPresentaddress(Address presentaddress) {
        this.presentaddress = presentaddress;
    }

    public void setPermanentaddress(Address permanentaddress) {
        this.permanentaddress = permanentaddress;
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public String getStatus() {
        return status;
    }

    public Address getPresentaddress() {
        return presentaddress;
    }

    public Address getPermanentaddress() {
        return permanentaddress;
    }

    public Customer(String name, String id, String status) {
        this.name = name;
        this.id = id;
        this.status = status;
    }
}
