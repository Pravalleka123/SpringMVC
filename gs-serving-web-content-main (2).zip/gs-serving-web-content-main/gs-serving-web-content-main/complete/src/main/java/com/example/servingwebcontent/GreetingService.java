package com.example.servingwebcontent;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class GreetingService
{
    @Autowired
    AddressService addressService;
    public Customer greetingser(String name,Boolean zipcode)
    {
        Customer cust=new Customer(name,"15","active");
        Address presentaddress=addressService.getpresentaddress("hyd","TG","522001");
        Address permanentaddress=addressService.getpermanentaddress("guntur","AP","52222");
        if(zipcode == false)
        {
            presentaddress.setZipcode("");
            permanentaddress.setZipcode("");
        }
        cust.setPresentaddress(presentaddress);
        cust.setPermanentaddress(permanentaddress);
        return cust;
    }


}
